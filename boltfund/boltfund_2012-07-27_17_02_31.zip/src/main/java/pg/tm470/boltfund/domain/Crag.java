package pg.tm470.boltfund.domain;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.EntityManager;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Size;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.jpa.activerecord.RooJpaActiveRecord;
import org.springframework.roo.addon.json.RooJson;
import org.springframework.roo.addon.tostring.RooToString;

@RooJavaBean
@RooToString
@RooJpaActiveRecord
@RooJson(deepSerialize = true)
public class Crag {

    @Size(max = 20)
    private String name;

    @Size(max = 5000)
    private String description;

    @Size(max = 2000)
    private String notes;

    @Size(max = 5000)
    private String access;

    @Size(max = 20)
    private String rockType;

    private Integer height;

    @ManyToOne
    private Ranking ranking;

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<Season> season = new HashSet<Season>();

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<PrintedGuide> guides = new HashSet<PrintedGuide>();

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<Infos> infos = new HashSet<Infos>();

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "crag")
    private Set<Sector> sectors = new HashSet<Sector>();
    
    
    public static List<pg.tm470.boltfund.domain.Crag> findByExampleLike(pg.tm470.boltfund.domain.Crag c, int firstResult, int maxResults, String sortColumn, String sortDir) {
        EntityManager em = Crag.entityManager();
        Session session = (Session) em.getDelegate();
        Example example = Example.create(c).ignoreCase().enableLike(MatchMode.ANYWHERE);
        Criteria criteria = session.createCriteria(Crag.class).add(example).setFirstResult(firstResult).setMaxResults(maxResults).addOrder("desc".equals(sortDir) ? Order.desc(sortColumn) : Order.asc(sortColumn));
        return criteria.list();
    }

    public static long countByExampleLike(pg.tm470.boltfund.domain.Crag c) {
        EntityManager em = Crag.entityManager();
        Session session = (Session) em.getDelegate();
        Example example = Example.create(c).ignoreCase().enableLike(MatchMode.ANYWHERE);
        Criteria criteria = session.createCriteria(Crag.class).add(example).setProjection(Projections.rowCount());
        return (Long) criteria.uniqueResult();
    }
}
