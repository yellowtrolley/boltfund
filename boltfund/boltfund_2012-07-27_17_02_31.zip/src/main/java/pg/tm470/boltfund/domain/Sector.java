package pg.tm470.boltfund.domain;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Size;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.jpa.activerecord.RooJpaActiveRecord;
import org.springframework.roo.addon.json.RooJson;
import org.springframework.roo.addon.tostring.RooToString;

@RooJavaBean
@RooToString
@RooJpaActiveRecord
@RooJson(deepSerialize = true)
public class Sector {

    @Size(max = 20)
    private String name;

    @Size(max = 5000)
    private String description;

    @Size(max = 2000)
    private String notes;

    @Size(max = 5000)
    private String access;

    @ManyToOne
    private Ranking ranking;

    @ManyToOne
    private Crag crag;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "sector")
    private Set<Route> routes = new HashSet<Route>();
}
