package pg.tm470.boltfund.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.roo.addon.web.mvc.controller.json.RooWebJson;
import org.springframework.roo.addon.web.mvc.controller.scaffold.RooWebScaffold;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import pg.tm470.boltfund.domain.Crag;
import pg.tm470.boltfund.domain.Infos;
import pg.tm470.boltfund.domain.PrintedGuide;
import pg.tm470.boltfund.domain.Ranking;
import pg.tm470.boltfund.domain.Season;
import pg.tm470.boltfund.domain.Sector;
import pg.tm470.boltfund.web.datatables.DataTablesRequest;
import pg.tm470.boltfund.web.datatables.DataTablesResponse;
import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;

@RooWebJson(jsonObject = Crag.class)
@Controller
@RequestMapping("/crags")
@RooWebScaffold(path = "crags", formBackingObject = Crag.class)
public class CragController {
	/*
	 *  sEcho=1&
	    iColumns=3
	    sColumns=&
	    iDisplayStart=0&
	    iDisplayLength=10&
	    mDataProp_0=0&
	    mDataProp_1=1&
	    mDataProp_2=2&
	    sSearch=&
	    bRegex=false&
	    sSearch_0=&
	    bRegex_0=false&
	    bSearchable_0=true&
	    sSearch_1=&
	    bRegex_1=false&
	    bSearchable_1=true&
	    sSearch_2=&
	    bRegex_2=false&
	    bSearchable_2=true&
	    iSortCol_0=0&
	    sSortDir_0=asc&
	    iSortingCols=1&
	    bSortable_0=true&
	    bSortable_1=true&
	    bSortable_2=true&
	 */
	
	@RequestMapping(value = "/listData", method = RequestMethod.POST, headers = "Accept=application/json")
    @ResponseBody
    public ResponseEntity<String> listData(@RequestBody String json) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/json; charset=utf-8");
        
        List<Crag> data = new ArrayList<Crag>();

        DataTablesRequest<Crag> dataTablesRequest = new JSONDeserializer<DataTablesRequest<Crag>>()
        		.use(Date.class, new DateTransformer("dd/MM/yyyy") ) // TODO Manage Timestamp
        		.use("searchObj", Crag.class)
        		.use(null, DataTablesRequest.class)
        		.deserialize(json);
        
        data = Crag.findByExampleLike(dataTablesRequest.searchObj, 
        		dataTablesRequest.iDisplayStart, 
        		dataTablesRequest.iDisplayLength, 
        		dataTablesRequest.amDataProp.get(dataTablesRequest.aiSortCol.get(0)), 
        		dataTablesRequest.asSortDir.get(0));

        Long totalRecords = Crag.countByExampleLike(dataTablesRequest.searchObj);

        DataTablesResponse<Crag> result = new DataTablesResponse<Crag>(""+dataTablesRequest.sEcho, 
        		totalRecords.intValue(), 
        		totalRecords.intValue(), 
        		data, 
        		dataTablesRequest.sColumns);
    	
    	return new ResponseEntity<String>(new JSONSerializer().exclude("*.class").deepSerialize(result), headers, HttpStatus.OK);
    }

	@RequestMapping(params = "form", produces = "text/html")
    public String createForm(Model uiModel) {
        uiModel.addAttribute("crag", new Crag());
        uiModel.addAttribute("sector", new Sector());
        uiModel.addAttribute("infoses", Infos.findAllInfoses());
        uiModel.addAttribute("printedguides", PrintedGuide.findAllPrintedGuides());
        uiModel.addAttribute("rankings", Ranking.findAllRankings());
        uiModel.addAttribute("seasons", Season.findAllSeasons());
        uiModel.addAttribute("sectors", Sector.findAllSectors());

        return "crags/create";
    }

	@RequestMapping(method = RequestMethod.POST, produces = "text/html")
    public String create(@Valid Crag crag, BindingResult bindingResult, Model uiModel, HttpServletRequest httpServletRequest) {
        if (bindingResult.hasErrors()) {
            populateEditForm(uiModel, crag);
            return "crags/create";
        }
        uiModel.asMap().clear();
        crag.persist();
        return "redirect:/crags/" + encodeUrlPathSegment(crag.getId().toString(), httpServletRequest);
    }

	@RequestMapping(value = "/{id}", params = "form", produces = "text/html")
    public String updateForm(@PathVariable("id") Long id, Model uiModel) {
        populateEditForm(uiModel, Crag.findCrag(id));
        return "crags/update";
    }

	@RequestMapping(method = RequestMethod.PUT, produces = "text/html")
    public String update(@Valid Crag crag, BindingResult bindingResult, Model uiModel, HttpServletRequest httpServletRequest) {
        if (bindingResult.hasErrors()) {
            populateEditForm(uiModel, crag);
            return "crags/update";
        }
        uiModel.asMap().clear();
        crag.merge();
        return "redirect:/crags/" + encodeUrlPathSegment(crag.getId().toString(), httpServletRequest);
    }
	

	void populateEditForm(Model uiModel, Crag crag) {
        uiModel.addAttribute("crag", crag);
        uiModel.addAttribute("infoses", Infos.findAllInfoses());
        uiModel.addAttribute("printedguides", PrintedGuide.findAllPrintedGuides());
        uiModel.addAttribute("rankings", Ranking.findAllRankings());
        uiModel.addAttribute("seasons", Season.findAllSeasons());
        uiModel.addAttribute("sectors", Sector.findAllSectors());
    }

}
