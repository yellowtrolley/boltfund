package pg.tm470.boltfund.domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.jpa.activerecord.RooJpaActiveRecord;
import org.springframework.roo.addon.json.RooJson;
import org.springframework.roo.addon.tostring.RooToString;

@RooJavaBean
@RooToString
@RooJpaActiveRecord
@RooJson(deepSerialize = true)
public class Route {

    @Size(max = 25)
    private String name;

    @Size(max = 2000)
    private String description;

    @Size(max = 1000)
    private String note;

    private Integer length;

    private Integer bolts;

    @NotNull
    @Past
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "M-")
    private Date dateCreated;

    @NotNull
    @Value("#{new java.util.Date()}")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "M-")
    private Date dateSubmitted;

    @Past
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "M-")
    private Date dateRebolted;

    @ManyToOne
    private Ranking ranking;

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<Style> style = new HashSet<Style>();

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<Grade> grade = new HashSet<Grade>();

    @ManyToOne
    private Sector sector;

    @ManyToMany(cascade = CascadeType.ALL, mappedBy = "routesBolted")
    private Set<Bolter> boltedBy = new HashSet<Bolter>();

    @ManyToMany(cascade = CascadeType.ALL, mappedBy = "routesRebolted")
    private Set<Bolter> reboltedBy = new HashSet<Bolter>();
}
