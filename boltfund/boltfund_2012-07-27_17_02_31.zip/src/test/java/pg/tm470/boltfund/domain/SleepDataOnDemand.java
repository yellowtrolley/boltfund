package pg.tm470.boltfund.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Sleep.class)
public class SleepDataOnDemand {
}
