package pg.tm470.boltfund.domain;


public enum AppRole {

    ADMIN, BOLTER, CLIMBER;
}
