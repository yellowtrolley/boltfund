package pg.tm470.boltfund.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Sleep.class)
public class SleepIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
