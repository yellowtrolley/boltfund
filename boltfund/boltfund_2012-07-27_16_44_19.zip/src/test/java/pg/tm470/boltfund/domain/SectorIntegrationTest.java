package pg.tm470.boltfund.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Sector.class)
public class SectorIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
