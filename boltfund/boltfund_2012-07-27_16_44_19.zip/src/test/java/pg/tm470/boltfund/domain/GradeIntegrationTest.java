package pg.tm470.boltfund.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Grade.class)
public class GradeIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
