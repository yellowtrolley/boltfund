package pg.tm470.boltfund.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Bolter.class)
public class BolterDataOnDemand {
}
